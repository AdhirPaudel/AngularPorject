import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserRoleChartComponent } from './user-role-chart.component';

describe('UserRoleChartComponent', () => {
  let component: UserRoleChartComponent;
  let fixture: ComponentFixture<UserRoleChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserRoleChartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserRoleChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
